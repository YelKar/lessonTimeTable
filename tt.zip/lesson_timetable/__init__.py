from lesson_timetable.table import TimeTable
